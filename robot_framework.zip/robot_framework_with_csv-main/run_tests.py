import os
import subprocess
import datetime

def main():
    """
    A wrapper script to run Robot Framework tests and save reports
    in a unique, timestamped directory.
    """
    # 1. Create a unique directory name with the current timestamp
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    report_dir = os.path.join("Reports", timestamp)

    # 2. Create the directory if it doesn't exist
    os.makedirs(report_dir, exist_ok=True)
    print(f"Reports will be saved to: {report_dir}")

    # 3. Define the path to your test suite(s)
    # IMPORTANT: Adjust this path to point to your test files or folder
    test_suite_path = "Tests" # Or "Tests/TC_01.robot" for a single file

    # 4. Construct the robot command with the --outputdir option
    command = [
        "robot",
        f"--outputdir={report_dir}",
        # You can add other options here, for example:
        # "--include=smoke",
        # "--variable=ENV:prod",
        test_suite_path
    ]

    print(f"\nExecuting command: {' '.join(command)}\n")

    # 5. Execute the tests
    try:
        # Use shell=True on Windows if 'robot' is not in PATH but in a venv
        subprocess.run(command, check=True, shell=False)
        print(f"\n✅ Test execution finished. Reports are available in: {report_dir}")
    except subprocess.CalledProcessError as e:
        print(f"\n❌ Test execution failed with exit code {e.returncode}.")
        print(f"Reports are available in: {report_dir}")
    except FileNotFoundError:
        print("\n💥 Error: 'robot' command not found.")
        print("Please make sure Robot Framework is installed and in your system's PATH.")
        print("If you are using a virtual environment, activate it first.")

if __name__ == "__main__":
    main()