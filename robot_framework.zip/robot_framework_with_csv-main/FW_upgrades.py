from robot import run
import os


class runner:
    def __init__(self, report_path="Reports"):
        self.report_path = report_path
        os.makedirs(self.report_path, exist_ok=True)

    #     # def start_suite(self, suite: object, testcases: object = None, tag: object = "sanity", loglevel: object = "DEBUG:INFO") -> object:
    # def start_suite(self, suite, testcases=None, loglevel="INFO"):
    def start_suite(self, suite: object, testcases: object = None, tag: object = "sanity",
                    loglevel: object = "DEBUG:INFO") -> object:
        """
        Run a Robot Framework suite.
        """
        suite_path = os.path.join("Test", f"{suite}.robot")

        if not os.path.exists(suite_path):
            raise FileNotFoundError(f"❌ Test suite not found: {suite_path}")

        if testcases is None:
            testcases = []

        # Inject global variables (used in setupteardown.robot)
        variables = {
            "WEB_URL": "https://admin-demo.nopcommerce.com/",
            "ELECTRON_APP": os.getenv("ELECTRON_APP", ""),
        }

        variable_args = [f"{key}:{value}" for key, value in variables.items()]

        print(f"▶️ Running suite: {suite_path}")
        print(f"📂 Reports: {self.report_path}")
        print(f"🧩 Injected Variables: {variables}")

        # Run Robot suite and return execution code
        result_code = run(
            suite_path,
            test=testcases,
            outputdir=self.report_path,
            loglevel=loglevel,
            variable=variable_args
        )

        return result_code

# ================================================================================================

# class runner:
#     def __init__(self, report_path="Reports//"):
#         self.report_path = report_path
#
#     def start_suite(self, suite: object, testcases: object = None, tag: object = "", loglevel: object = "DEBUG:INFO") -> object:
#         suite_path = "Test/" + suite + ".robot"
#         if testcases is None:
#             testcases = []
#         run(suite_path, test=testcases, outputdir=self.report_path, tag=tag, loglevel=loglevel)
#
#
#     def start_suite(self, suite: object, testcases: object = None, tag: object = "", loglevel: object = "DEBUG:INFO") -> object:
#         suite_path = "Test/" + suite + ".robot"
#         if testcases is None:
#             testcases = []
#         run(suite_path, test=testcases, outputdir=self.report_path, loglevel=loglevel)


# import os
# from robot import run as robot_run
#
# class runner:
#     def start_suite(self, suite, testcases=None, variables=None):
#         """
#         Executes the specified Robot Framework suite with optional test filtering
#         and variable injection.
#         """
#
#         suite_path = os.path.join("Test", f"{suite}.robot")
#
#         # Ensure suite file exists
#         if not os.path.exists(suite_path):
#             raise FileNotFoundError(f"❌ Suite file not found: {suite_path}")
#
#         # --- Build Robot arguments ---
#         robot_args = []
#
#         # Add test suite path first
#         robot_args.append(suite_path)
#
#         # Filter specific test cases if provided
#         if testcases:
#             for tc in testcases:
#                 robot_args += ["--test", tc]
#
#         # Inject variables (safe defaults)
#         if not variables:
#             variables = {}
#         if "ELECTRON_APP" not in variables:
#             variables["ELECTRON_APP"] = ""
#         if "WEB_URL" not in variables:
#             variables["WEB_URL"] = "https://admin-demo.nopcommerce.com/"
#
#         for key, value in variables.items():
#             robot_args += ["--variable", f"{key}:{value}"]
#
#         # Set output directory for reports
#         output_dir = os.path.join(os.getcwd(), "Reports")
#         os.makedirs(output_dir, exist_ok=True)
#         robot_args += ["--outputdir", output_dir]
#
#         # --- Logging ---
#         print("\n🚀 Running suite:", suite_path)
#         print("📋 Testcases:", testcases)
#         print("🌐 Variables:", variables)
#         print("📂 Reports directory:", output_dir, "\n")
#
#         # --- Run Robot suite ---
#         result_code = robot_run(*robot_args)
#
#         # Return Robot result (0 = PASS)
#         return result_code

# import os
# from robot import run as robot_run
#
# class runner:
#     def start_suite(self, suite, testcases=None, variables=None):
#         """
#         Executes the specified Robot Framework suite with optional test filtering
#         and variable injection.
#         """
#
#         suite_path = os.path.join("Test", f"{suite}.robot")
#
#         # --- Build Robot arguments ---
#         robot_args = [suite_path]
#
#         # Filter specific test cases if provided
#         if testcases:
#             for tc in testcases:
#                 robot_args += ["--test", tc]
#
#         # Inject variables (safe defaults)
#         if not variables:
#             variables = {}
#         if "ELECTRON_APP" not in variables:
#             variables["ELECTRON_APP"] = ""
#         if "WEB_URL" not in variables:
#             variables["WEB_URL"] = "https://admin-demo.nopcommerce.com/"
#
#         for key, value in variables.items():
#             robot_args += ["--variable", f"{key}:{value}"]
#
#         # Set output directory for reports
#         output_dir = os.path.join(os.getcwd(), "Reports")
#         os.makedirs(output_dir, exist_ok=True)
#         robot_args += ["--outputdir", output_dir]
#
#         # --- Logging ---
#         print(f"\n🚀 Running suite: {suite_path}")
#         print(f"📋 Testcases to execute: {testcases}")
#         print(f"🌐 Variables injected: {variables}")
#         print(f"📂 Reports directory: {output_dir}\n")
#
#         # --- Run Robot suite ---
#         result_code = robot_run(*robot_args)
#
#         # Return Robot result (0 = PASS)
#         return result_code


# from robot import run
# import os
# import csv
#
#
# class runner:
#     def __init__(self, report_path="Reports//"):
#         self.report_path = report_path
#
#     def start_suite(self, suite: object, testcases: object = None, tag: object = "", loglevel: object = "DEBUG:INFO") -> object:
#         suite_path = "Test/" + suite + ".robot"
#         if testcases is None:
#             testcases = []
#         run(suite_path, test=testcases, outputdir=self.report_path, tag=tag, loglevel=loglevel)
#
#
#     def start_suite(self, suite: object, testcases: object = None, tag: object = "", loglevel: object = "DEBUG:INFO") -> object:
#         suite_path = "Test/" + suite + ".robot"
#         if testcases is None:
#             testcases = []
#         run(suite_path, test=testcases, outputdir=self.report_path, loglevel=loglevel)
