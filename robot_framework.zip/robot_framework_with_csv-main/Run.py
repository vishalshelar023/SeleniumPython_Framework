from FW_upgrades import runner
from Library.Excel.TestData import load_test_data_and_get_TCIDs, update_test_result
from robot.api import ExecutionResult
import os

EXCEL_PATH = "E:\\Vishal Office\\robot_framework_with_csv-main\\Data\\data.xlsx"
SHEET_NAME = "data"

run = runner()

# Step 1: Load test data
List_of_TC_to_Execute = load_test_data_and_get_TCIDs(EXCEL_PATH, SHEET_NAME)
print("✅ Y-flagged Test Cases:", List_of_TC_to_Execute)

# Step 2: Run suite
if List_of_TC_to_Execute:
    run.start_suite(suite="TestSuite", testcases=List_of_TC_to_Execute)

    # Step 3: Read Robot output to update Excel
    output_xml = os.path.join(os.getcwd(), "Reports", "output.xml")
    if os.path.exists(output_xml):
        result = ExecutionResult(output_xml)
        for test in result.suite.tests:
            test_id = test.name
            status = test.status
            if status == "PASS":
                print(f"🟩 Updating Excel: {test_id} -> {status}")
            else:
                print(f"🟥 Updating Excel: {test_id} -> {status}")
            update_test_result(test_id, status, EXCEL_PATH, SHEET_NAME)
    else:
        print("❌ output.xml not found, skipping Excel update.")
else:
    print("⚠️ No Y-flagged test cases found.")



# try:
#     if List_of_TC_to_Execute:
#         run.start_suite(suite="TestSuite", testcases=List_of_TC_to_Execute)
#         # ... rest of the parsing and update logic ...
# except Exception as e:
#     print(f"💥 An unexpected error occurred: {e}")



# import openpyxl
# from FW_upgrades import runner
# from Library.Excel import Excel_fun_lib
# from Library.Excel import TestData
# #import TestID_Parameter
#
# run = runner()
#
# excel_path= "E:\\Vishal Office\\robot_framework_with_csv-main\\Data\\data.xlsx"
#
# rowcount = Excel_fun_lib.getRowCount(excel_path, "data")
# colcount = Excel_fun_lib.getColumnCount(excel_path, "data")
#
# workbook = openpyxl.load_workbook(excel_path)
# r_sheet = workbook["data"]
#
#
# run.start_suite(suite="TestSuite", testcases=["TC_01"])
# List_of_TC_to_Execute = []
# for rowindex in range (2, rowcount+1):
#     #for colindex in range (rowindex, 2):
#         #TestID_Parameter = {}
#
#         if (r_sheet.cell(rowindex,2).value) == "Y":
#             strTestCaseID = r_sheet.cell(rowindex, 1).value
#             List_of_TC_to_Execute.append(strTestCaseID)
#             print(List_of_TC_to_Execute)
#
# TestData.load_test_data()
# #print(TestID_Parameter.get('TC_01.Execute'))
#
# for TestCaseID in List_of_TC_to_Execute:
#     print(TestCaseID)
#     #run.start_suite(suite="TestSuite", testcases=[TestCaseID])
#
#     # List_of_TC_to_Execute = ['TC_01', 'TC_02', ...]
#     run.start_suite(suite="TestSuite", testcases=List_of_TC_to_Execute)
