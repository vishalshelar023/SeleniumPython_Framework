from Library.POM.Keywords import keywords
from Library.POM.Keywords.keywords import data
from selenium import webdriver
from selenium.webdriver.common.by import By

#driver = keywords.get_driver()
def perform_a_actions():
    data("parameter2")

    keywords.log_msg("adding quantity in field")
    driver = keywords.get_driver()
    #driver.find_element(By.xpath("//textarea[@title='Search']")
    res = driver.find_element(By.XPATH,"//textarea[@title='Search']").send_keys("webElement")
    if res:
        keywords.log_msg("Step as passed and quanty has beep entered")
        #keywords.get_screenshot()
    else:
        keywords.fail_test_case("there was an error when entering the qty")