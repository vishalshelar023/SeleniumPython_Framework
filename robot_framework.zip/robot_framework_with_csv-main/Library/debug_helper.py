def get_browser_kwargs(electron_app_path, web_url):
    """
    Determines the correct keyword arguments for opening a browser.

    Returns a dictionary to be unpacked as named arguments in Robot Framework,
    ensuring the correct parameters are passed for both web and electron apps.

    Args:
        electron_app_path: The path to the Electron application. Empty string if not used.
        web_url: The URL for the web browser.

    Returns:
        A dictionary containing the correct named arguments.
    """
    if electron_app_path:
        # If the electron path is not empty, return arguments for Electron
        return {"app_type": "electron", "electron_path": electron_app_path}
    else:
        # Otherwise, return arguments for the web browser
        return {"app_type": "web", "url": web_url}