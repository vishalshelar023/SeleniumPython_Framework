from Library.POM import Keywords
from Library.POM.Keywords import keywords as kw
from Library.POM.Keywords.keywords import data
from Library.Excel.TestData import get_param
from selenium import webdriver
from selenium.webdriver.common.by import By

# from selenium import webdriver
# from selenium.webdriver.chrome.service import Service as ChromeService
# from webdriver_manager.chrome import ChromeDriverManager
#
# driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))

#----- XPaths ------
xp_url_login = "//a[text()='Log in']"
xp_tb_email = "//input[@id='Email']"
xp_tb_password = "//input[@id='Password']"
xp_bt_login= "//button[text() = 'Log in']"


def login():
    print("Into Login Function")
    Tdata = get_param("TC_01.Para1")
    print("TC_01.Para1 "+str(Tdata))
    # kw.kw_enter_text(xp_tb_email,"admin@yourstore.com")
    # kw.kw_enter_text(xp_tb_password,"admin")
    # kw.kw_click_button(xp_bt_login)
    #kw.kw_click_button(xp_bt_login)





