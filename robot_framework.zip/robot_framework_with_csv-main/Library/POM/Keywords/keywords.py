#from lib2to3.pgen2 import driver

#from SeleniumLibrary import keywords
from robot.libraries.BuiltIn import BuiltIn
from robot.api import logger
from selenium.webdriver.common.by import By

from Library.POM.Keywords import keywords



# Functions for Data
##############################################

def get_variable(variable):
    return BuiltIn().get_variable_value("${"+str(variable)+"}")

def data(variable):
    test_case = get_variable("TEST_NAME")
    return get_variable(test_case+"."+str(variable))

def set_test_variable(variable, value):
    BuiltIn().set_test_variable("${"+str(variable)+"}", value)

def set_suite_variable(variable, value):
    BuiltIn().set_suite_variable("${"+str(variable)+"}", value)

#  Function for logging
##############################################




def log_msg(str_text=""):
    logger.info(str_text)
    logger.console(str_text)

def log_debug(str_text=""):
    logger.debug(str_text)

def log_console(str_text=""):
    logger.console(str_text)

def fail_test_case(str_text=""):
    BuiltIn().fail(str_text)

# Functions for Selenium
##############################################

def get_SeleniumLibrary_instance():
    builtin = BuiltIn()
    return builtin.get_library_instance("SeleniumLibrary")

def get_driver():
    return get_SeleniumLibrary_instance().driver

def get_screenshot():
    get_SeleniumLibrary_instance().capture_page_screenshot()

#-----------------Functions for Selenium Actions----------------

#xpath = "res = driver.find_element(By.XPATH,"//textarea[@title='Search']").send_keys("webElement")"
# def kw_enter_text(xpath):
#     logger.console("Entering text to: xpath")
#     driver = keywords.get_driver()
#     res = driver.find_element(By.XPATH, "//textarea[@title='Search']").send_keys("webElement")



def kw_click_url(url):
    driver = keywords.get_driver()
    driver.find_element(By.XPATH, url).click()

def kw_click_button(xpath):
    driver = keywords.get_driver()
    driver.find_element(By.XPATH, xpath).click()

def kw_click_radio_button(url):
    driver = keywords.get_driver()
    driver.find_element(By.XPATH, url).click()
def kw_enter_text(xpath, text):
    driver = keywords.get_driver()
    driver.find_element(By.XPATH, xpath).clear()
    driver.find_element(By.XPATH, xpath).send_keys(text)

def kw_select_dropdown(url):
    driver = keywords.get_driver()
    driver.find_element(By.XPATH, url).click()




