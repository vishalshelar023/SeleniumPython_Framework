import openpyxl
import os
from Library.Excel import Excel_fun_lib
from openpyxl.styles import PatternFill

# Global dictionary to store test data
TestID_Parameter = {}

# --------------------------
# Load test data and Y-flagged TestCases
# --------------------------
def load_test_data_and_get_TCIDs(
        excel_path="E:\\Vishal Office\\robot_framework_with_csv-main\\Data\\data.xlsx",
        sheet_name="data"):
    """
    Loads all test data flagged with 'Y' into a dictionary and returns list of Y-flagged TestCaseIDs.
    """
    global TestID_Parameter
    TestID_Parameter.clear()

    workbook = openpyxl.load_workbook(excel_path)
    sheet = workbook[sheet_name]

    rowcount = Excel_fun_lib.getRowCount(excel_path, sheet_name)
    colcount = Excel_fun_lib.getColumnCount(excel_path, sheet_name)

    List_of_TC_to_Execute = []

    for rowindex in range(2, rowcount + 1):
        flag = str(sheet.cell(rowindex, 2).value).strip().upper()
        if flag == "Y":
            test_id = sheet.cell(rowindex, 1).value
            List_of_TC_to_Execute.append(test_id)

            # Load all parameters for this test case
            for colindex in range(2, colcount + 1):
                param_name = sheet.cell(1, colindex).value
                param_value = sheet.cell(rowindex, colindex).value
                key = f"{test_id}.{param_name}"
                TestID_Parameter[key] = param_value

    return List_of_TC_to_Execute


# --------------------------
# Fetch parameter
# --------------------------
def get_param(key):
    """Fetch a parameter value by key."""
    return TestID_Parameter.get(key)


# Robot keyword wrapper
def get_test_param(key):
    """
    [Robot Keyword]
    Fetch test parameter directly inside Robot Framework.
    Example:
        ${username}=    Get Test Param    TC_01.Para1
    """
    return get_param(key)


# --------------------------
# Update Excel with PASS/FAIL
# --------------------------
def update_test_result(test_id, status, excel_path=None, sheet_name="data"):
    """
    Update the Excel sheet with PASS/FAIL result for a test case.
    Creates 'Status' column if it does not exist.
    """
    if excel_path is None:
        excel_path = os.getenv("EXCEL_PATH", "E:\\Vishal Office\\robot_framework_with_csv-main\\Data\\data.xlsx")

    wb = openpyxl.load_workbook(excel_path)
    sheet = wb[sheet_name]

    # Find or create Status column
    status_col = None
    for colindex in range(1, sheet.max_column + 1):
        header = str(sheet.cell(1, colindex).value).strip().lower()
        if header == "status":
            status_col = colindex
            break
    if not status_col:
        status_col = sheet.max_column + 1
        sheet.cell(1, status_col, "Status")

    # Locate test_id row
    for rowindex in range(2, sheet.max_row + 1):
        tid = str(sheet.cell(rowindex, 1).value).strip()
        if tid == test_id:
            cell = sheet.cell(rowindex, status_col)
            cell.value = status.upper()
            # Apply color
            if status.upper() == "PASS":
                cell.fill = PatternFill(start_color="90EE90", end_color="90EE90", fill_type="solid")
            elif status.upper() == "FAIL":
                cell.fill = PatternFill(start_color="FF4433", end_color="FF4433", fill_type="solid")
            break

    wb.save(excel_path)
    wb.close()


# --------------------------
# Auto-load test data when imported
# --------------------------
def _auto_load():
    excel_path = os.getenv("EXCEL_PATH", "E:\\Vishal Office\\robot_framework_with_csv-main\\Data\\data.xlsx")
    sheet_name = os.getenv("SHEET_NAME", "data")
    if not TestID_Parameter:
        load_test_data_and_get_TCIDs(excel_path, sheet_name)


_auto_load()


# from tkinter import Variable
#
# import openpyxl
# from Library.Excel import Excel_fun_lib
# from selenium import webdriver
#
# # excel_path = "E:\\Vishal Office\\robot_framework_with_csv-main\\Data\\data.xlsx"
# #
# # rowcount = Excel_fun_lib.getRowCount(excel_path, "data")
# # colcount = Excel_fun_lib.getColumnCount(excel_path, "data")
# #
# # workbook = openpyxl.load_workbook(excel_path)
# # r_sheet = workbook.get_sheet_by_name("data")
#
# def save_test_data():
#     excel_path = "E:\\Vishal Office\\robot_framework_with_csv-main\\Data\\data.xlsx"
#
#     rowcount = Excel_fun_lib.getRowCount(excel_path, "data")
#     colcount = Excel_fun_lib.getColumnCount(excel_path, "data")
#
#     workbook = openpyxl.load_workbook(excel_path)
#     r_sheet = workbook.get_sheet_by_name("data")
#
#     TestID_Parameter = {}
#     for rowindex in range (2, rowcount+1):
#         for colindex in range (2, colcount+1):
#
#             if (r_sheet.cell(rowindex,2).value) == "Y":
#                 strTestCaseID = r_sheet.cell(rowindex,1).value
#                 strParametername = r_sheet.cell(1, colindex).value
#                 strParametervalue = r_sheet.cell(rowindex, colindex).value
#                 strkey = strTestCaseID +"."+strParametername
#                 TestID_Parameter[strkey] = strParametervalue
#
#     for k, v in TestID_Parameter.items():
#         print(f"{k}: {v}")
#
#
