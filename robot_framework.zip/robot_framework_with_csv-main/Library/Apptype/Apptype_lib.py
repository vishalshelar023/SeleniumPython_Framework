from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
import os


class Apptype_lib:
    def __init__(self):
        self.driver = None

    def open_browser(self, url=None, browser="chrome", app_type="web", electron_path=None):
        """Open Web or Electron browser."""
        if app_type.lower() == "web":
            self.driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))
            self.driver.maximize_window()
            if url:
                self.driver.get(url)
        elif app_type.lower() == "electron":
            if not electron_path or not os.path.exists(electron_path):
                raise Exception("Valid Electron app path must be provided")
            options = webdriver.ChromeOptions()
            options.binary_location = electron_path
            self.driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()), options=options)
        else:
            raise Exception("Invalid app_type. Use 'web' or 'electron'.")
        return self.driver

    def close_browser(self):
        """Close the browser."""
        if self.driver:
            self.driver.quit()

    def click_element(self, by, locator):
        self.driver.find_element(getattr(By, by.upper()), locator).click()

    def input_text(self, by, locator, text):
        self.driver.find_element(getattr(By, by.upper()), locator).send_keys(text)



# from selenium import webdriver
# from selenium.webdriver.chrome.service import Service as ChromeService
# from selenium.webdriver.common.by import By
# from webdriver_manager.chrome import ChromeDriverManager
# import os
#
# class BrowserLibrary:
#     def __init__(self):
#         self.driver = None
#
#     def open_browser(self, url=None, browser="chrome", app_type="web", electron_path=None):
#         """Open Web or Electron browser."""
#         if app_type.lower() == "web":
#             self.driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))
#             self.driver.maximize_window()
#             if url:
#                 self.driver.get(url)
#         elif app_type.lower() == "electron":
#             if not electron_path or not os.path.exists(electron_path):
#                 raise Exception("Valid Electron app path must be provided")
#             options = webdriver.ChromeOptions()
#             options.binary_location = electron_path
#             self.driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()), options=options)
#         else:
#             raise Exception("Invalid app_type. Use 'web' or 'electron'.")
#         return self.driver
#
#     def close_browser(self):
#         """Close the browser."""
#         if self.driver:
#             self.driver.quit()
#
#     def click_element(self, by, locator):
#         self.driver.find_element(getattr(By, by.upper()), locator).click()
#
#     def input_text(self, by, locator, text):
#         self.driver.find_element(getattr(By, by.upper()), locator).send_keys(text)


# from selenium import webdriver
# from selenium.webdriver.chrome.service import Service as ChromeService
# from selenium.webdriver.common.by import By
# from webdriver_manager.chrome import ChromeDriverManager
# import os
#
# class BrowserLibrary:
#     def __init__(self):
#         self.driver = None
#
#     def open_browser(self, url=None, browser="chrome", app_type="web", electron_path=None):
#         if app_type.lower() == "web":
#             self.driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))
#             self.driver.maximize_window()
#             if url:
#                 self.driver.get(url)
#
#         elif app_type.lower() == "electron":
#             if not electron_path or not os.path.exists(electron_path):
#                 raise Exception("Valid Electron app path must be provided")
#             options = webdriver.ChromeOptions()
#             options.binary_location = electron_path
#             self.driver = webdriver.Chrome(
#                 service=ChromeService(ChromeDriverManager().install()),
#                 options=options
#             )
#         else:
#             raise Exception("Invalid app_type. Use 'web' or 'electron'.")
#
#         return self.driver
#
#     def click_element(self, by, locator):
#         self.driver.find_element(getattr(By, by.upper()), locator).click()
#
#     def input_text(self, by, locator, text):
#         self.driver.find_element(getattr(By, by.upper()), locator).send_keys(text)
#
#     def close_browser(self):
#         if self.driver:
#             self.driver.quit()
